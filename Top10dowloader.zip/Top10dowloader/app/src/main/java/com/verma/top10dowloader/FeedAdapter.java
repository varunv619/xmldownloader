package com.verma.top10dowloader;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * Created by JMDJMD on 12/11/2016.
 */

public class FeedAdapter extends ArrayAdapter {

    private static final String TAG = "FeedAdapter";

    private final LayoutInflater inflator;
    private List<FeedEntry> applications;
    private final int layoutresource;

    public FeedAdapter(Context context, int resource, List<FeedEntry> applications) {
        super(context, resource);
        this.applications = applications;
        this.layoutresource = resource;
        this.inflator = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return applications.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;

        if (convertView == null){

            convertView = inflator.inflate(layoutresource,parent,false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);

        }else{
           viewHolder= (ViewHolder) convertView.getTag();
        }
       // View view = inflator.inflate(layoutresource,parent,false);
       // TextView tvname = (TextView) convertView.findViewById(R.id.tvName);
        //TextView tvartist = (TextView) convertView.findViewById(R.id.tvArtist);
        // TextView tvsummary = (TextView) convertView.findViewById(R.id.textView3);

        FeedEntry currentapplication = applications.get(position);
        viewHolder.tvName.setText(currentapplication.getName());
        viewHolder.tvArtist.setText(currentapplication.getArtist());
        viewHolder.tvSummary.setText(currentapplication.getSummary());

        return convertView;

    }

    //improve code by creating viewholder, so we don't need to find views again

    private class ViewHolder{

        final TextView tvName;
        final TextView tvArtist;
        final TextView tvSummary;

        ViewHolder(View v){

            tvName = (TextView) v.findViewById(R.id.tvName);
            tvArtist = (TextView)v.findViewById(R.id.tvArtist);
            tvSummary = (TextView)v.findViewById(R.id.textView3);
        }
    }
}
