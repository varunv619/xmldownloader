package com.verma.top10dowloader;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;

/**
 * Created by JMDJMD on 12/10/2016.
 */

public class ParseApplications {

    private static final String TAG = "ParseApplications";
    ArrayList<FeedEntry> arrapplications = new ArrayList<>();

    public ParseApplications() {

        this.arrapplications = new ArrayList<>();
    }

    public ArrayList<FeedEntry> getArrapplications() {
        return arrapplications;
    }

    public boolean parse(String xmldata){

        boolean status = false;
        boolean inentry = false;
        FeedEntry currentrecord = null;
        String textvalue = "";

        try{

            XmlPullParserFactory factory;
            factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(xmldata));
            int event= xpp.getEventType();

            while(event!=XmlPullParser.END_DOCUMENT){

                String tagname = xpp.getName();

                switch (event) {

                    case XmlPullParser.START_TAG:
                        Log.d(TAG, "parse: starting tag"+tagname);
                        if("entry".equalsIgnoreCase(tagname)) {
                            inentry = true;
                            currentrecord = new FeedEntry();
                        }
                        break;

                    case XmlPullParser.TEXT:
                        textvalue =xpp.getText();
                        break;

                    case XmlPullParser.END_TAG:
                        Log.d(TAG, "parse: ending tag"+tagname);
                        if(inentry){

                            if("entry".equalsIgnoreCase(tagname)){
                                arrapplications.add(currentrecord);
                               inentry = false;
                            }
                            else if("name".equalsIgnoreCase(tagname)){
                                currentrecord.setName(textvalue);
                            }
                            else if("artist".equalsIgnoreCase(tagname)){
                                currentrecord.setArtist(textvalue);
                            }
                            else if("releasedate".equalsIgnoreCase(tagname)){
                                currentrecord.setReleasedate(textvalue);
                            }
                            else if("summary".equalsIgnoreCase(tagname)){
                                currentrecord.setSummary(textvalue);
                            }
                            else if("image".equalsIgnoreCase(tagname)){
                                currentrecord.setImageURL(textvalue);
                            }
                        }
                        break;

                    default:
                        //nothing to do
                }
                event = xpp.next();
            }
            
            for(FeedEntry app: arrapplications){

                Log.d(TAG, "parse: *********************");
                Log.d(TAG, app.toString());
            }

        }catch(Exception e)
        {
         status = false;
            e.printStackTrace();
        }
    return status;
    }
}
