package com.verma.top10dowloader;

/**
 * Created by JMDJMD on 12/10/2016.
 */

public class FeedEntry {

    private String name;
    private String releasedate;
    private String imageURL;
    private String summary;
    private String artist;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReleasedate() {
        return releasedate;
    }

    public void setReleasedate(String releasedate) {
        this.releasedate = releasedate;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    @Override
    public String toString() {
        return "FeedEntry{" +
                "artist='" + artist + '\n' +
                ", imageURL='" + imageURL + '\n' +
                ", releasedate='" + releasedate + '\n' +
                ", name='" + name + '\n';

    }
}
