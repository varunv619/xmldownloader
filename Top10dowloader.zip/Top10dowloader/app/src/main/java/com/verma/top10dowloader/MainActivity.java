package com.verma.top10dowloader;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ListView listapps;
    private String feedUrl = "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=%d/xml";
    private int feedlimit = 10;
    private String cachedUrl = "Invalidated";
    public static final String STATE_URL ="feedURL";
    public static final String STATE_LIMIT="feedLIMIT";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listapps = (ListView) findViewById(R.id.xmllistview) ;

        if(savedInstanceState != null){

            feedlimit = savedInstanceState.getInt(STATE_LIMIT);
            feedUrl = savedInstanceState.getString(STATE_URL);
        }

        Log.d(TAG, "onCreate: starting Asyntask");
        downloadURL(String.format(feedUrl,feedlimit));
        Log.d(TAG, "onCreate: finished");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.feeds_menu,menu);
        if(feedlimit == 10){
            menu.findItem(R.id.mnutop10).setCheckable(true);
        }else{
            menu.findItem(R.id.mnutop25).setCheckable(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id =item.getItemId();
        //int grpid = item.getGroupId();


        switch(id){

            case R.id.mnuFree:
            feedUrl ="http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topfreeapplications/limit=%d/xml";
                    break;

            case R.id.mnuPaid:
                feedUrl = "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/toppaidapplications/limit=%d/xml";
                break;

            case R.id.mnuSong:
                feedUrl= "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topsongs/limit=%d/xml";
                break;

            case R.id.mnutop10:
            case R.id.mnutop25:
                if(!item.isChecked()){
                    item.setCheckable(true);
                    feedlimit = 35 - feedlimit;
                    Log.d(TAG, "onOptionsItemSelected: "+ item.getTitle()+ "setting feedlimit to" + feedlimit);
                }else{
                    Log.d(TAG, "onOptionsItemSelected: "+ item.getTitle()+"feedlimit unchanged");
                }
                 break;

            case R.id.mnurefresh:
                cachedUrl = "INVALID";
                break;
            default:
                return super.onOptionsItemSelected(item);
        }

    downloadURL(String.format(feedUrl,feedlimit));
    return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        outState.putString(STATE_URL, feedUrl);
        outState.putInt(STATE_LIMIT, feedlimit);
        super.onSaveInstanceState(outState);
    }


    private void downloadURL(String feedURL){

        if(!feedURL.equalsIgnoreCase(cachedUrl)) {

            Log.d(TAG, "downloadURL: starting Asyntask");
            Downloader downloader = new Downloader();
            downloader.execute(feedURL);
            cachedUrl = feedURL;
            Log.d(TAG, "downloadURL: finished");
        }else{
            Log.d(TAG, "downloadURL: URL not changed");
        }
    }

    private class Downloader extends AsyncTask<String, Void, String> {
        private static final String TAG = "downloader";

        @Override
        protected String doInBackground(String... strings) {
            Log.d(TAG, "doInBackground: starts with" + strings[0]);
            String rssfeed = downloadurl(strings[0]);

            if (rssfeed == null) {
                Log.e(TAG, "doInBackground: rssfeed error");
            }
            return rssfeed;

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            //Log.d(TAG, "onPostExecute: parameter is" + s);
            ParseApplications parseapplication = new ParseApplications();
            parseapplication.parse(s);

            //ArrayAdapter<FeedEntry> arrayadapter = new ArrayAdapter<FeedEntry>(
              //      MainActivity.this, R.layout.list_item, parseapplication.getArrapplications()
            //);
            //listapps.setAdapter(arrayadapter);

            FeedAdapter feedadapter = new FeedAdapter(MainActivity.this, R.layout.list_format, parseapplication.getArrapplications());
            listapps.setAdapter(feedadapter);

        }

        private String downloadurl(String urlpath) {
            StringBuilder xmlresult = new StringBuilder();

            try {
                URL url = new URL(urlpath);
                HttpURLConnection urlconnection = (HttpURLConnection) url.openConnection();
                int response = urlconnection.getResponseCode();
                InputStream inputstream = urlconnection.getInputStream();
                InputStreamReader istreamreader = new InputStreamReader(inputstream);
                BufferedReader buffreader = new BufferedReader(istreamreader);

                int charsread;
                char[] inputbuffreader = new char[800];

                while (true) {
                    charsread = buffreader.read(inputbuffreader);

                    if (charsread < 0) {
                        break;
                    }
                    if (charsread > 0) {

                        xmlresult.append(String.copyValueOf(inputbuffreader, 0, charsread));
                    }
                }
                buffreader.close();
                return xmlresult.toString();
            } catch (MalformedURLException e) {
                Log.e(TAG, "downloadurl: error+" + e.getMessage());
            } catch (IOException e) {
                Log.e(TAG, "downloadurl: IO error" + e.getMessage());
            } catch (SecurityException e) {
                Log.e(TAG, "downloadurl: Security error, need permission?" + e.getMessage());
            }
            return null;
        }
    }

}









